xss-bot is https://github.com/kevin-mizu/bot-ctf-template

but with a cookie added on https://challenge/

Flag is in the cookie

You can use netcat to connect to port 9002 and submit an URL to XSS the bot

You can use https://webhook.site/ to exfiltrate content
